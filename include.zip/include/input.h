#pragma once

void mouseInput();
void keyInput(); 


