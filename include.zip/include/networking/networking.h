#pragma once

void initNetworking();
void updateNetworking();
